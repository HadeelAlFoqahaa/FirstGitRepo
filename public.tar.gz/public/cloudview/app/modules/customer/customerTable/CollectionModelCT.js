define([
    'App',
    'modules/customer/customerTable/model'
],
function(
   App,
   CustomerModel
){ 
	return Backbone.Collection.extend({
	    model:CustomerModel,
	    url: 'hadeel/customer'
    });
});