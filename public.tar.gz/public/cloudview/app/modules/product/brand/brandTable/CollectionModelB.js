define([
    'App',
    'modules/product/brand/brandTable/model'
],
function(
   App,
   BrandModel
){ 
	return Backbone.Collection.extend({
	    model:BrandModel,
	    url: 'hadeel/brand'	,
	    initialize : function(){
  	  },
    });
});