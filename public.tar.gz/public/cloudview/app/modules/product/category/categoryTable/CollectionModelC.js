define([
    'App',
    'modules/product/category/categoryTable/model'
],
function(
   App,
   CategoryModel
){ 
	return Backbone.Collection.extend({
	    model:CategoryModel	,
	    url: 'hadeel/category',
    });
});