define([
	'App',
    'text!modules/product/brand/brandTable/brandRow/template.html',

],
function(
	App,
	template
){
	return Backbone.Marionette.ItemView.extend({
		tagName: "tr",
		template: _.template(template),
	});
});