define([
	'App',
	'text!modules/product/property/addNewProperty/template.html',
	'modules/product/property/propertyTable/model'
],
function(
	App,
	template,
	CustomerModel
){
	return Backbone.Marionette.ItemView.extend({
		template: _.template(template),
		events:{
			"click #saveProperty" : "savePropertyFun",
		},
		savePropertyFun : function(){
            if ($('#propertyName').val() != "") {
                this.model.set({"name": $('#propertyName').val()});
            }
            else{
            	alert("Property name cann\'t be empty");
            	return false;
            }
            this.model.save();
		},
	});
});