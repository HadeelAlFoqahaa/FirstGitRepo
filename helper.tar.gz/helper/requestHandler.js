var mysql = require('mysql')
module.exports = function(app) {
	return {
		get: function(req, cb) {

			var id = req.param('id');
			var table_name = req.param('tbl_name');
			var query = 'select * from ??'
			var args = [table_name];
			if (id) {
				query = 'select * from ?? where id = ?'
				args = [table_name, id];
			}

			app.db.query(query, args, function(err, data) {
				console.log(this.sql)
				if (err) {
					return cb(err);
				}
				if (id) {
					if (data.length == 0) {
						return cb(404)
					}
				}

				if (id) {
					cb(null, data[0]);
				} else {
					cb(null, data)
				}
			});

		},
		post: function(req, cb) {
			app.db.query('INSERT INTO ?? SET ?', [req.param('tbl_name'), req.body], function(err, result) {
				
				if(err){
					return cb(err)
				}

				console.log(this.sql);
				// insertId

				app.db.query('select * from ?? where id = ?', [req.param('tbl_name'), result.insertId], function(err, result) {

					console.log(this.sql);
					return cb(err, result);
				});

			});
		},
		put: function(req, cb) {
			var id = req.param('id');
			if (!id) {
				return cb(404);
			}

			app.db.query('update ?? SET ? where id = ?', [req.param('tbl_name'), req.body, id], function(err, result) {
				console.log(this.sql);

				app.db.query('select * from ?? where id = ?', [req.param('tbl_name'), id], function(err, result) {
					console.log(this.sql);
					return cb(err, result);
				});
			});
		},
		delete: function(req, cb) {
			var id = req.param('id');
			if (!id) {
				return cb(404);
			}

			app.db.query('delete from ?? where id = ?', [req.param('tbl_name'), id], function(err, result) {
				console.log(this.sql);
				return cb(err, result);
			});

		}

	}
}



/**/