define([
	'App',
    'text!modules/purchaseOrder/purchaseOrderRow/template.html',

],
function(
	App,
	template
){
	return Backbone.Marionette.ItemView.extend({
		tagName: "tr",
		className:"Founded",
		template: _.template(template)
	});
});