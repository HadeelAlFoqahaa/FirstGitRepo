define([
	'App',
	'text!modules/order/orderDetails/orderDetailsTable/template.html',
	'modules/order/orderDetails/orderDetailsTable/CollectionModelD',
	'modules/order/orderDetails/orderDetailsTable/model',
	'modules/order/orderDetails/orderDetailsTable/orderDetailsRow/view',
],
function(
	App,
	template,
	OrderDetailsCollection,
	OrderDetailsModel,
	OrderDetailsRowView

){
	return Backbone.Marionette.CompositeView.extend({
		template: _.template(template),
		childView: OrderDetailsRowView,
		childViewContainer: "tbody",
		initialize :function(){

			// this.collection = new OrderDetailsCollection();
			// //this.collection.on('sync',this.render,this);  
			// //this.collection.fetch();
			// //var Order1 = new OrderModel({  OrderName: "Hadeel" });
			// //var Order2 = new OrderModel({  OrderName: "Rawan" });
			// //console.log(Order1.toJSON());
			// this.collection.add([
			// 	{  
			// 		Num: 1 ,
			// 		CustomerName:"Hadeel",
			// 	    Date:"12/7/2009"
			// 	},
			// 	{  
			// 		Num: 2,
			// 		CustomerName:"Rawan",
			// 	    Date:"12/7/2009"
			// 	}
			// ]);
		}
    });
});