define([
    'App',
    'modules/order/orderDetails/orderDetailsTable/model'
],
function(
   App,
   OrderDetailsModel
){ 
	return Backbone.Collection.extend({
	    model:OrderDetailsModel	
    });
});