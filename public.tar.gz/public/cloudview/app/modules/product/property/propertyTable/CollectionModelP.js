define([
    'App',
    'modules/product/property/propertyTable/model'
],
function(
   App,
   PropertyModel
){ 
	return Backbone.Collection.extend({
	    model:PropertyModel,
	    url:"hadeel/property"
    });
});