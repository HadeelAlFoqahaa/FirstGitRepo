define([
	'App',
	'text!common/views/menu/template.html'
],
function(
	App,
	template
){
	return Backbone.Marionette.ItemView.extend({
		template: _.template(template),
		events:{
			"click #logOut":"logoutFun"
		},
		logoutFun: function(){
			App.Router.navigate('login',true);
		}
	});
});