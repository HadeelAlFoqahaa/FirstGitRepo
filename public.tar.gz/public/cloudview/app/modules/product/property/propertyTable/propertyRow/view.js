define([
	'App',
    'text!modules/product/property/propertyTable/propertyRow/template.html',

],
function(
	App,
	template
){
	return Backbone.Marionette.ItemView.extend({
		tagName: "tr",
		template: _.template(template),
		events:{
			"click .delete-P" : "deletePropertyItem",
			"click .edit-P"   : "editPropertyItem",
			"click .update-P" : "updatePropertyItem",
		},
		deletePropertyItem:function(){
          this.model.destroy();
        },
        editPropertyItem : function(){
            this.triggerMethod("editProperty",this.model);
        },
        updatePropertyItem :function(){
           this.model.set({'name':$('.propertyNameInput').val()}); 
           this.model.save();
        }
	});
});