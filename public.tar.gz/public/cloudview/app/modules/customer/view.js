define([
	'App',
	'text!modules/customer/template.html',
	'modules/customer/customerTable/model',
	'modules/customer/addNewCustomer/view',
	'modules/customer/customerTable/view'

], function(
	App,
	template,
	CustomerModel,
	AddNewCustomer,
	CustomerTableView
){

	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
		events:{
			"click .addBtnC" : "toggle"
		},
		childEvents:{
            "editCustomer"  : "editCustomerFun"
    	},
		regions:{
			body:".ScrollStyle",
			form: "#formC"
        },
		toggle : function(){
			this.getRegion('form').show(new AddNewCustomer({model: new CustomerModel}));
			$("#formC").show();
		},
		editCustomerFun : function(data,model){
            this.getRegion('form').show(new AddNewCustomer({model : model}));
			this.$('#formC').show();
		},
		onRender:function(){
			this.getRegion('body').show(new CustomerTableView());
		}
	});
});