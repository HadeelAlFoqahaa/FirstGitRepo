define([
	'App',
	'text!modules/purchaseOrder/template.html',
	'modules/purchaseOrder/purchaseOrderRow/view'
], function(
	App,
	template,
	PurchaseOrderRow
){

	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
		regions:{
			body: ".anothorRow"
		},
		events:{
			"click #btnAddTr" : "addAnothorRow"
		},
		onRender:function(){
			var purchaseOrderDate =  new Date();
			purchaseOrderDate.setDate(purchaseOrderDate.getDate());
			this.$("#orderDate").val(purchaseOrderDate.toISOString().substring(0,10));
		},
		addAnothorRow: function(){
			if (!$.isEmptyObject($.find('.anothorRow'))) {
			   this.getRegion('body').show(new PurchaseOrderRow());
		    }
		    else{
		    	this.getRegion('body').show(new PurchaseOrderRow());
		    }
		}
	});
});