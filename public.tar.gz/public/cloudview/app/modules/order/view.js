define([
	'App',
	'text!modules/order/template.html',
	'modules/order/orderTable/view'
], function(
	App,
	template,
	OrderTableView
){

	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
		regions:{
			body:".ScrollStyle",
			mainRegion:"Body"
        },
        events:{

        },
        onRender:function(){
			this.getRegion('body').show(new OrderTableView());
		}
	});
});