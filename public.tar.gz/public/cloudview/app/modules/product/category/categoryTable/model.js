define([
    'App',
],
function(
   App
){
	return Backbone.Model.extend({
		defaults:{	
		   name :"",
		},
		idAttribute: "id",
		urlRoot:"hadeel/category",
		getCategoryID: function(){
            return this.get('id');
		},
		getCategoryName: function(){
            return this.get('name');
		}
	});
});