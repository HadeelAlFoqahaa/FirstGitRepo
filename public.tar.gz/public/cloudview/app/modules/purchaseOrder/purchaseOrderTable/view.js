define([
	'App',
	'text!modules/purchaseOrder/purchaseOrderTable/template.html',
	'modules/purchaseOrder/purchaseOrderTable/CollectionModelO',
	'modules/purchaseOrder/purchaseOrderTable/model',
	'modules/purchaseOrder/purchaseOrderTable/purchaseOrderRow/view',
],
function(
	App,
	template,
	PurchaseOrderCollection,
	PurchaseOrderModel,
	PurchaseOrderRowView

){
	return Backbone.Marionette.CompositeView.extend({
		template: _.template(template),
		childView: PurchaseOrderRowView,
		childViewContainer: "tbody",
		initialize :function(){

			this.collection = new PurchaseOrderCollection();
			//this.collection.on('sync',this.render,this);  
			//this.collection.fetch();
			//var Order1 = new OrderModel({  OrderName: "Hadeel" });
			//var Order2 = new OrderModel({  OrderName: "Rawan" });
			//console.log(Order1.toJSON());
			this.collection.add([
				{  
					Num: 1 ,
					CustomerName:"Hadeel",
				    Date:"12/7/2009"
				},
				{  
					Num: 2,
					CustomerName:"Rawan",
				    Date:"12/7/2009"
				}
			]);
		}
    });
});