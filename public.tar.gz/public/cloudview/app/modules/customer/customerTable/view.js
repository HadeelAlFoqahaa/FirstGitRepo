define([
	'App',
	'text!modules/customer/customerTable/template.html',
	'modules/customer/customerTable/CollectionModelCT',
	'modules/customer/customerTable/model',
	'modules/customer/customerTable/customerRow/view',
],
function(
	App,
	template,
	CustomerCollection,
	CustomerModel,
	CustomerRowView

){
	return Backbone.Marionette.CompositeView.extend({
		template: _.template(template),
		childView: CustomerRowView,
		childViewContainer: "tbody",
		initialize :function(options){
			this.model = options.model;
			this.collection = new CustomerCollection();
			this.collection.fetch();
		}
    });
});