define([
	'App',
	'modules/product/brand/brandTable/CollectionModelB',
	'modules/product/brand/brandCollection/brandOption/view',
],
function(
	App,
	BrandCollection,
	BrandOptionView

){
	return Backbone.Marionette.CollectionView.extend({
		tagName:"select",
		className:"brands",
		childView: BrandOptionView,
		collection:new BrandCollection(),
		initialize :function(){
			//var value = $('.categories option:selected').attr('value');
			//this.collection = new BrandCollection();
			//this.filter();
		},	
		filter: function (child, index, collection) {
            return child.get('category_id')  == $('.categories option:selected').attr('value');
        },
        onRender: function(){
        	this.collection.fetch({});
        }
	});
});