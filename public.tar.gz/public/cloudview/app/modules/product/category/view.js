define([
	'App',
	'text!modules/product/category/template.html',
	'modules/product/category/categoryTable/view',
	'modules/product/category/categoryTable/model',
	'modules/product/category/categoryTable/CollectionModelC',
	'modules/product/category/addCategoryItem/view'
],
function(
	App,
	template,
	CategoryTableView,
	CategoryModel,
	CategoryCollection,
	AddCategoryView
){
	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
		regions:{
			table : "#tableC",
			form  : ".form"
		},
		events:{
			"click #addBtn"     : "toggle",
    	},
    	childEvents:{
            "editCategoryItem"  : "editCategoryItemFun"
    	},
		toggle : function(){
			this.getRegion('form').show(new AddCategoryView({model: new CategoryModel }));
			this.$('.form').show();
		},
		editCategoryItemFun : function(data,model){
            this.getRegion('form').show(new AddCategoryView({model : model}));
			this.$('.form').slideToggle();
		},
		onRender : function(){
			this.getRegion('table').show(new CategoryTableView());
		},
	});
});