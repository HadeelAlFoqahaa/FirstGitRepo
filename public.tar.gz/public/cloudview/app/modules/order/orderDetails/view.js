define([
	'App',
    'text!modules/order/orderDetails/template.html',
    'modules/order/orderDetails/orderDetailsTable/view',
],
function(
	App,
	template,
	OrderDetailsTableView
){
	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
		regions:{
			body:"#templateTable"
		},
		onRender:function(){
			this.getRegion('body').show(new OrderDetailsTableView());
		}
	});
});