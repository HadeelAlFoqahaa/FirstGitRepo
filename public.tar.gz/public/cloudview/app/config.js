require.config( {

    paths: {
        jquery: 'bower_components/jquery/dist/jquery.min',

        underscore: 'bower_components/underscore/underscore-min',

        text: 'bower_components/text/text',

        backbone: 'bower_components/backbone/backbone-min',

        marionette: 'bower_components/marionette/lib/backbone.marionette.min',

        routefilter: '../libraries/backbone.routefilter',
    },

    shim: {

        jquery: {
            exports: '$'
        },

        underscore: {
            exports: '_'
        },

        backbone: {
            deps: [ 'underscore', 'jquery' ],
            exports: 'Backbone'
        },

        marionette : {
            deps: [ 'jquery', 'underscore', 'backbone' ],
            exports: 'Marionette'
        },

        routefilter: {
            deps : [ 'backbone' ],
            exports : 'routefilter'
        },
    },

    baseURL: 'app',

    deps : ['startup'],

    callback : function () {
        /* what to do after require loads */
    }
});
