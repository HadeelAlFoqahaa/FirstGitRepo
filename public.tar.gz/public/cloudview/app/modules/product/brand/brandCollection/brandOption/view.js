define([
	'App',
	//'text!modules/product/brand/brandCollection/brandOption/template.html'
],
function(
	App
	//template
){
	return Backbone.Marionette.ItemView.extend({
		//template: _.template(template),
		tagName:"option",
		attributes: function(){
        	// return{
        	//   name : this.model.get('category_id'),
        	//  /* style:"display:none;"*/
         //    }
        },	
        render: function(){
        	//if(this.model.get('category-id')){ 
        	  $(this.el).attr('value',this.model.get('id')).html(this.model.get('name'));
           // }
        },
      
	});
});