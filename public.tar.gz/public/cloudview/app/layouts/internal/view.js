define([
	'App',
	'common/views/menu/view',
	'text!layouts/internal/template.html'
],
function(
	App,
	MenuView,
	template
){
	return Backbone.Marionette.LayoutView.extend({
		
		el: '#wrapper',

		template: _.template(template),

		regions: {
			menu: '.menu',
			content: '#mainRegion'
		},

		onRender: function(){
			this.getRegion('menu').show(new MenuView());
		},

		onDestroy: function(){
			$('body').append( $('<div/>', {id: 'wrapper'}));
		},

		getType: function(){
			return 'internal';
		}
		
	});
});