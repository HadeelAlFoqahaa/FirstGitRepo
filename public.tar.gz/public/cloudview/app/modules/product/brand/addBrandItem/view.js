define([
	'App',
	'text!modules/product/brand/addBrandItem/template.html',
	'modules/product/brand/brandTable/model',
	'modules/product/category/categoryCollection/view',
],
function(
	App,
	template,
	CategoryModel,
	CategoryListView
){
	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
		regions:{
            categorylist : ".CategoryFoBrandList"
		},
		events:{
			"click #saveBrand"   : "saveBrandFun",
		},
		saveBrandFun: function(){
			var value = $('select option:selected').attr('value');
            this.model.set({'category_id' : value }) ;
			this.model.set('name' , $('#brandName').val() );
			this.model.save();
        },
        onRender : function(){	
			this.getRegion('categorylist').show(new CategoryListView());
		},
	});
});