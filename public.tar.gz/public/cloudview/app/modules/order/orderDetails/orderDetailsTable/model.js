define([
    'App',
],
function(
   App
){
	return Backbone.Model.extend({
		defaults:{
		   //ID:0,
		   Num :0,
		   CustomerName:"",
		   Date:"",
		   BrandID:0,
		   BrandName:"",
		   CategoryName:"",
		   ItemName:"",
		   CategoryID:0,
		   ItemID:0,
		   Quantity:0
		},
		//idAttribute: "ID",
		url: 'http://192.168.2.89:3030/hadeel/orderDetails'
	});
});