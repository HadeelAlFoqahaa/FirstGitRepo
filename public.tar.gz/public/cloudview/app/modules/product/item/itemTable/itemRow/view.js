define([
	'App',
    'text!modules/product/item/itemTable/itemRow/template.html',

],
function(
	App,
	template
){
	return Backbone.Marionette.ItemView.extend({
		tagName: "tr",
		template: _.template(template),
		events:{
			"click .edit-Item" : "edit",
			"click .delete-Item" : "deleteItem",
		},
		edit : function(){
        },
		deleteItem : function(){
           this.model.destroy();
		}
	});
});