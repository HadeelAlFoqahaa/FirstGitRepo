define([
    'App',
    'modules/order/orderTable/model'
],
function(
   App,
   OrderModel
){ 
	return Backbone.Collection.extend({
	    model:OrderModel	
    });
});