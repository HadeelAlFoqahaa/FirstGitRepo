define([
    'App',
],
function(
   App
){
	return Backbone.Model.extend({
		defaults:{
		   name:"",
           count: "",
           price:"",
		},
		idAttribute: "id",
		urlRoot: 'hadeel/item'
	});
});