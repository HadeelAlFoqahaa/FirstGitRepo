define([
    'App',
],
function(
   App
){
	return Backbone.Model.extend({
		defaults:{
		   name :"",
		   phone:"",
		   address:""
		},
		// validate:function(attrs){
  //           if(!attrs.name){
  //           	alert("name connot be empty");
  //           }
		// },
		idAttribute: "id",
		urlRoot: 'hadeel/customer'
	});
});