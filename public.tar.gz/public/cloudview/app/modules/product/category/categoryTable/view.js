define([
	'App',
	'text!modules/product/category/categoryTable/template.html',
	'modules/product/category/categoryTable/CollectionModelC',
	'modules/product/category/categoryTable/model',
	'modules/product/category/categoryTable/categoryRow/view',
],
function(
	App,
	template,
	CategoryCollection,
	CategoryModel,
	CategoryRowView

){
	return Backbone.Marionette.CompositeView.extend({
		template: _.template(template),
		childView: CategoryRowView,
		childViewContainer: "tbody",

		initialize :function(options){
			this.model = options.model;
			this.collection = new CategoryCollection();
	        this.collection.fetch();
	        //this.collection.on("change" , this);
	        //this.collection.on("add" ,(model, collection, options)); 
	        //this.collection.listenTo(this.collection.model, "add", this.render);
	        this.collection.bind("add", this.collection.render, this); 
		},	
    });
});