define([
	'App',
    'text!modules/order/orderTable/orderRow/template.html',
    'modules/order/view',
    'modules/order/orderDetails/view',
],
function(
	App,
	template,
	OrderView,
	OrderDetails
){
	return Backbone.Marionette.ItemView.extend({
		tagName: "tr",
		template: _.template(template),
		events:{
			"click #showDetails" :"showDetailsFun"
		},
		showDetailsFun:function(){
			//OrderView.getRegion('body').reset();
            //this.getRegion('mainRegion').show(new OrderDetails());
            App.Router.navigate('orderDetails',true);
		}
	});
});