define([
    'App',
    'modules/purchaseOrder/purchaseOrderTable/model'
],
function(
   App,
   PurchaseOrderModel
){ 
	return Backbone.Collection.extend({
	    model:PurchaseOrderModel	
    });
});