define([
    'App',
],
function(
   App
){
	return Backbone.Model.extend({
		defaults:{
		   name:""
		},
		idAttribute: "id",
		urlRoot: 'hadeel/property',
		getPropertyID: function(){
            return this.get('id');
		},
		getPropertyName: function(){
            return this.get('name');
		}
	});
});