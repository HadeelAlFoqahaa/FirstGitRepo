define([
	'App',
    'text!modules/product/category/categoryTable/categoryRow/template.html',
    'modules/product/category/categoryTable/model',
    'modules/product/category/categoryTable/view',

],
function(
	App,
	template,
	CategoryModel,
	CategoryView
){
	return Backbone.Marionette.ItemView.extend({
		tagName: "tr",
		template: _.template(template),
		//model: CategoryModel,
		events:{
        	"click #delete-C" : "deleteCategoryItem",
        	"click #edit-C"   : "editCategory",
        },
        initialize:function(){
	    	var self = this;
	    	this.model.on('change',function(){
	        	setTimeout(function(){
	        		self.render();
	        	},30);
	        },this);
	        this.model.collection.on('add',self.render,this);
	    },
        deleteCategoryItem:function(){
          this.model.destroy();
        },
        editCategory:function(){  
        	this.triggerMethod("editCategoryItem", this.model);
        },
	});
});