define([
	'App',
	'text!modules/product/brand/brandTable/template.html',
	'modules/product/brand/brandTable/CollectionModelB',
	'modules/product/brand/brandTable/model',
	'modules/product/brand/brandTable/brandRow/view',
	'modules/product/category/categoryCollection/view'
],
function(
	App,
	template,
	BrandCollection,
	BrandModel,
	BrandRowView,
	CategoryView

){
	return Backbone.Marionette.CompositeView.extend({
		template: _.template(template),
		childView: BrandRowView,
		childViewContainer: "tbody",
		collection:  new BrandCollection(),
		initialize :function(){
		
		},
        onRender:function(){
        	this.collection.fetch();
        },
        filter: function (child, index, collection) {
            return child.get('category_id')  == $('.categories option:selected').attr('value');
        }
    });
});