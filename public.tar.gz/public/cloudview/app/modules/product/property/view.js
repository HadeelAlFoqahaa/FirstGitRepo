define([
	'App',
	'text!modules/product/property/template.html',
	'modules/product/property/propertyTable/view',
	'modules/product/property/addNewProperty/view',
	'modules/product/property/propertyTable/model'
],
function(
	App,
	template,
	PropertyTableView,
	AddNewProperty,
	PropertyModel
){
	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
		regions:{
			table: "#tableP",
			form :".formP"
		},
		events:{
			"click #addBtnP" : "toggle",
		},
		childEvents:{
			"editProperty" : "editPropertyFun"
		},
		editPropertyFun : function(data,model){
			this.getRegion('form').show(new AddNewProperty({model:model}));
			$(".formP").show();
		},
		toggle : function(){
			this.getRegion('form').show(new AddNewProperty({model: new PropertyModel}));
			$(".formP").show();
		},
		onRender : function(){
			this.getRegion('table').show(new PropertyTableView());
		},
	});
});