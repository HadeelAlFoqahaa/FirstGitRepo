define([
    'App',
],
function(
   App
){
	return Backbone.Model.extend({
		defaults:{
		   //ID:0,
		   Num :0,
		   CustomerName:"",
		   Date:""
		},
		//idAttribute: "ID",
		url: 'http://192.168.2.89:3030/hadeel/order'
	});
});