define([
	'App',
	'text!layouts/external/template.html'
],
function(
	App,
	template
){
	return Backbone.Marionette.LayoutView.extend({
		
		el: '#wrapper',

		template: _.template(template),

		regions: {
			content: ".halfOfPage"
		},

		onDestroy: function(){
			$('body').append( $('<div/>', {id: 'wrapper'}));
		},

		getType: function(){
			return 'external';
		}
	});
});