define([
	'App',
	'text!modules/login/template.html'
], function(
	App,
	template
){

	return Backbone.Marionette.LayoutView.extend({
		className:'logo',
		template: _.template(template)
	});
});