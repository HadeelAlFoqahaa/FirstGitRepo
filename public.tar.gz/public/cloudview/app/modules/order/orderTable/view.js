define([
	'App',
	'text!modules/order/orderTable/template.html',
	'modules/order/orderTable/CollectionModelO',
	'modules/order/orderTable/model',
	'modules/order/orderTable/orderRow/view',
],
function(
	App,
	template,
	OrderCollection,
	OrderModel,
	OrderRowView

){
	return Backbone.Marionette.CompositeView.extend({
		template: _.template(template),
		childView: OrderRowView,
		childViewContainer: "tbody",
		initialize :function(){

			this.collection = new OrderCollection();
			//this.collection.on('sync',this.render,this);  
			//this.collection.fetch();
			//var Order1 = new OrderModel({  OrderName: "Hadeel" });
			//var Order2 = new OrderModel({  OrderName: "Rawan" });
			//console.log(Order1.toJSON());
			this.collection.add([
				{  
					Num: 1 ,
					CustomerName:"Hadeel",
				    Date:"12/7/2009"
				},
				{  
					Num: 2,
					CustomerName:"Rawan",
				    Date:"12/7/2009"
				}
			]);
		}
    });
});