define([
	'App',
    'text!modules/product/category/categoryCollection/categoryOption/template.html',
    'modules/product/category/categoryTable/model'

],
function(
	App,
	template,
	CategoryModel
){
	return Backbone.Marionette.ItemView.extend({
		tagName:"option",
		template: _.template(template),
		attributes : function () {
            // Return model id
            return {
                value    : this.model.get('id')
            }
        },	
	});
});