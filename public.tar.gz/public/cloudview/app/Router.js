define([
	'App',
	'marionette',
	'layouts/external/view',
	'layouts/internal/view',
	'modules/login/view',
	'modules/customer/view',
	'modules/order/view',
    'modules/purchaseOrder/view',
    'modules/product/view',
    'modules/order/orderDetails/view'
],
function (
	App,
	Marionette,
	ExternalView,
	InternalView,
	LoginView,
	CustomerView,
	OrderView,
	PurchaseOrderView,
	ProductView,
	OrderDetailsView
) {
	return Marionette.AppRouter.extend({

		routes: {
			/**
			 * External Routes
			 */
			''				: 'loginRoute',
			'login' 		: 'loginRoute',

			/**
			 * Internal Routes
			 */
			'customer'      :'customerRoute',
			'order'         :'orderRoute',
			'purchaseOrder' :'purchaseOrderRoute',
			'product'       :'productRoute',
			'addItem'       :'addItemRoute',
			'orderDetails'  :'orderDetailsRoute'
		},

		withoutAuthRoutes: ['', 'login'],

		/**
		 * Routes that don't need authentication (External Routes)
		 */
		//withoutAuthRoutes: ['', 'login','player/*path','browser'],

		loginRoute: function () {
			App.rootView.getRegion('content').show(new LoginView());
		},

		customerRoute: function () {
			App.rootView.getRegion('content').show(new CustomerView());
		},
		orderRoute: function () {
			App.rootView.getRegion('content').show(new OrderView());
		},
		purchaseOrderRoute: function () {
			App.rootView.getRegion('content').show(new PurchaseOrderView());
		},
		productRoute: function () {
			App.rootView.getRegion('content').show(new ProductView());
		},
		orderDetailsRoute: function(){
			App.rootView.getRegion('content').show(new OrderDetailsView());
		},
		/**
		 * this function is called internally before routing
		 * it is a hack of backbone by calling the plugin libs/backbone.routefilter.js
		 */
		before: function (route, params, callback) {
			
			App.route    = {'route': route};

			var noAuth = _.contains(this.withoutAuthRoutes, route);

			if (noAuth) {
				// render external view
				if (_.isUndefined(App.rootView)) {
					App.rootView = new ExternalView();
					App.rootView.render();
				}
				else if (App.rootView.getType() != 'external') {
					App.rootView.destroy();
					App.rootView = new ExternalView();
					App.rootView.render();
				}
			}
			else {
				if (_.isUndefined(App.rootView)) {
					App.rootView = new InternalView();
					App.rootView.render();
				}
				else if (App.rootView.getType() != 'internal') {
					App.rootView.destroy();
					App.rootView = new InternalView();
					App.rootView.render();
				}
			}

			return callback();
		},

		/**
		 * this function is called internally after routing
		 * it is a hack of backbone by calling the plugin libs/plugins/backbone.routefilter.js
		 */
		after: function (route, params) {
			
		}
	});
});