define([
	'App',
    'text!modules/customer/customerTable/customerRow/template.html',

],
function(
	App,
	template
){
	return Backbone.Marionette.ItemView.extend({
		tagName: "tr",
		template: _.template(template),
		events:{
            "click #delete-C" : "deleteCustomer"  ,
            "click #edit-C"   : "editCustomerRow"
		},
		initialize:function(){
	    	var self = this;
	    	this.model.on('change',function(){
	        	setTimeout(function(){
	        		self.render();
	        	},30);
	        },this);
	        this.model.collection.on('add',self.render,this);
	    },
		deleteCustomer:function(){
          this.model.destroy();
        },
		editCustomerRow:function(){  
        	this.triggerMethod("editCustomer", this.model);
        },
	});
});