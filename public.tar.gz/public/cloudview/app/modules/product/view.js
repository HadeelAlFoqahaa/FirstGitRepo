define([
	'App',
	'modules/product/category/view',
	'modules/product/brand/view',
	'modules/product/property/view',
	'modules/product/item/view',
	'text!modules/product/template.html'
], function(
	App,
	CategoryView,
	BrandView,
	PropertyView,
	ItemEView,
	template
){

	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
		regions: {
			leftSide:".leftSide",
			rightSide:".Body"
		},
		events:{
			"click #list1" : "loadPageForList1",
			"click #list2" : "loadPageForList2",
			"click #list3" : "loadPageForList3",
			"click #list4" : "loadPageForList4",
		},

		/*initialize : function(){
			
		},*/

		loadPageForList1:function(){
			this.getRegion('rightSide').show(new CategoryView());
		},

		loadPageForList2:function(){
		    //this.getRegion('rightSide').show(new MenuView());
		    this.getRegion('rightSide').show(new BrandView());
		},
		loadPageForList3:function(){
			this.getRegion('rightSide').show(new PropertyView());	
		},
		loadPageForList4:function(){
			this.getRegion('rightSide').show(new ItemEView());
		}
	});
});