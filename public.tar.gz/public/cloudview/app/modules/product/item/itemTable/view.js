define([
	'App',
	'text!modules/product/item/itemTable/template.html',
	'modules/product/item/itemTable/CollectionModelT',
	'modules/product/item/itemTable/model',
	'modules/product/item/itemTable/itemRow/view'
],
function(
	App,
	template,
	ItemCollection,
	ItemModel,
	ItemRowView

){
	return Backbone.Marionette.CompositeView.extend({
		template: _.template(template),
		childView: ItemRowView,
		childViewContainer: "tbody",
		initialize :function(){
			this.collection = new ItemCollection();  
			this.collection.fetch();
		}
    });
});