define([
	'App',
	'modules/product/category/categoryTable/CollectionModelC',
	'modules/product/category/categoryTable/model',
	'modules/product/category/categoryCollection/categoryOption/view',
	'modules/product/brand/brandCollection/view',
	'modules/product/brand/brandTable/CollectionModelB',
],
function(
	App,
	CategoryCollection,
	CategoryModel,
	CategoryOptionView,
	BrandViewList,
	BrandModels

){
	return Backbone.Marionette.CollectionView.extend({
		tagName:"select",
		className:"categories",
		childView: CategoryOptionView,
		events: {
            "change": "changeText"
        },
		initialize :function(){
			this.collection = new CategoryCollection();
	        this.collection.fetch();
		},	
		changeText: function() { 
            var value = $('.categories option:selected').attr('value');
            //alert(value);
            //var brandView = new BrandViewList();
            //var brandModels = new BrandModels();
            //brandView.brandModels.
            //brandView.model.collection(); 
            this.triggerMethod("changed");
        }
	});
});