define([
    'App',
    'modules/product/item/itemTable/model'
],
function(
   App,
   ItemModel
){ 
	return Backbone.Collection.extend({
	    model:ItemModel	,
	    url:"hadeel/item"
    });
});