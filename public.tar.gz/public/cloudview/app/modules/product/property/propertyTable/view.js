define([
	'App',
	'text!modules/product/property/propertyTable/template.html',
	'modules/product/property/propertyTable/CollectionModelP',
	'modules/product/property/propertyTable/model',
	'modules/product/property/propertyTable/propertyRow/view'
],
function(
	App,
	template,
	PropertyCollection,
	PropertyModel,
	PropertyRowView

){
	return Backbone.Marionette.CompositeView.extend({
		template: _.template(template),
		childView: PropertyRowView,
		childViewContainer: "tbody",
		initialize :function(){
			this.collection = new PropertyCollection();
			this.collection.fetch();
		}
    });
});