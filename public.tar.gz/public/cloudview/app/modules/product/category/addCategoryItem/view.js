define([
	'App',
	'text!modules/product/category/addCategoryItem/template.html',
	'modules/product/category/categoryTable/model'
],
function(
	App,
	template,
	CategoryModel
){
	return Backbone.Marionette.ItemView.extend({
		template: _.template(template),
		events:{
			"click #saveCategory"   : "saveCategoryFun",
		},
		initialize : function(options){
			this.model = options.model;
		},
		saveCategoryFun: function(){
			this.model.set('name' , $('#category').val() );
			this.model.save();
        },
	});
});