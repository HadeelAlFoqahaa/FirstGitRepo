define([
	'App',
	'text!modules/product/item/template.html',
    'modules/product/item/itemTable/view',
    'modules/product/item/addItem/view',
    'modules/product/category/categoryTable/CollectionModelC',
    'modules/product/category/categoryCollection/view',
    'modules/product/brand/brandCollection/view',
    'modules/product/brand/brandTable/model',
    'modules/product/brand/brandTable/CollectionModelB',

],
function(
	App,
	template,
	ItemTableView,
	AddItemView,
	CategoryCollection,
	CategoryListView,
	BrandListView,
	BrandModel,
	BrandCollection
){
	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
		regions: {
			table: "#tableT",
			itemList:".itemList",
			list:"#categoryForItem",
			Blist:".brandForItem",
		},
		events:{
			"click #addItem" : "addNewItem",
        },
		childEvents:{
			"changed" : "setSelectedIdFun"
		},
		onRender : function(){
			this.getRegion('table').show(new ItemTableView());
		    this.getRegion('list').show(new CategoryListView({}));
		   // var collections = new BrandCollection({});
		    //this.getRegion('Blist').show(new BrandListView(/*{ collection : collections}*/));
		},
		setSelectedIdFun :function(){
			//this.getRegion('Blist').reset();
             
            // I need for loop that is call a function show 
           /* for (var i = 0; i < $('.brands').length; i++) {
                this.show();
            }*/
            this.getRegion('Blist').show(new BrandListView(/*{ collection : collections}*/));
        },
        show :function(){
            var  value = $('.categories option:selected').attr('value');
            var categoryId = [] ;
            for (var i = 1; i < $(".brands").length+1; i++) {
              categoryId[i]== $('.brands option:nth-child('+i+')').attr('name');
            }

            for (var i = 1; i < $(".brands").length+1; i++) {
              if(value==categoryId[i]);
               //$(".brands").children("option last").show();
               $('.brands option:nth-child('+i+')').show();
            }
            //or we can use recursive function to recall itself
        
            //if(_.contians()
            //var brandModel = new BrandModel();
            //var match = _.matches({ brandModel.get("category-id"): value});
            //var collections = new BrandCollection({});
            //collections = _.filter(collections, match);
			//this.getRegion('Blist').show(new BrandListView({collection: collections}));
			//var copy = $.merge([],collections);
			// if(categoryId == value){
			//console.log(value);
			//console.log(collections.at(0));
			//var models = collections.at(0);
			//alert(models.get("id"));
			// var brandModels = collections.filter(function(model) {
          //              return model.get('category_id') == value;
           //          });
            //var brandCollection = new BrandCollection({brandModels});
            //this.getRegion('Blist').show(new BrandListView({collection: brandCollection}));
			//    console.log(categoryId);
			//    $('.brands option').show();
		    //    }
		    //  var filter =_.filter(copy,value);
		},
        addNewItem: function(){
           this.getRegion('itemList').show(new AddItemView());
        }
	});
});