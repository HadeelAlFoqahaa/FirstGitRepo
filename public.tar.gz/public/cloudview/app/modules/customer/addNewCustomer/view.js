define([
	'App',
	'text!modules/customer/addNewCustomer/template.html',
	'modules/customer/customerTable/model'
],
function(
	App,
	template,
	CustomerModel
){
	return Backbone.Marionette.ItemView.extend({
		template: _.template(template),
		events:{
			"click #saveCustomer"   : "saveCustomerFun",
		},
		initialize : function(options){
			this.model = options.model;
		},
		saveCustomerFun: function(){
			
			if ($('#customer').val() != "") {
				this.model.set('name' , $('#customer').val() );
			}
			else{
				alert("Customer Name cann\'t be empty");
				return false;
			}
			if ($('#phone').val() != ""){
				if ($.isNumeric($('#phone').val())){
				   this.model.set('phone' , $('#phone').val() );
				}
				else{
                   alert("You must enter a number");
				   return false;
				}
			}
			else{
				alert("Number cann\'t be empty");
				return false;
			}
			if ($('#address').val() != "") {
				this.model.set('address' , $('#address').val() );
		    }
		    else{
				alert("Address cann\'t be empty");
				return false;
			}
		    this.model.save();
        },
	});
});