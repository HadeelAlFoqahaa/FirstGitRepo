define([
    'App',
],
function(
   App
){
	return Backbone.Model.extend({
		defaults:{
		   name:""
		},
		idAttribute: "id",
		url: 'hadeel/brand',
		initialize: function(){
		},
	});
});