define([
	'App',
	'text!modules/product/item/addItem/template.html',
], function(
	App,
	template
){

	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
	});
});
