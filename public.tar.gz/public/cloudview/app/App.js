define([
    'jquery',
    'underscore',
    'backbone',
    'marionette',
    'routefilter'
],
function (
    $,
    _,
    Backbone,
    Marionette,
    routefilter
) {
    var App = new Backbone.Marionette.Application();

    App.currentRoutes = {};

    App.on("before:start", function (options) {

    });

    App.on("start", function (options) {
        if (Backbone.history)
            Backbone.history.start();

        //preventDefault for all anchor tags
        // using event delegation to attach only one event to DOM
       /* Backbone.$(document).on("click", "a", function (e) {
            e.preventDefault();
        });*/
    });

    window.log = function(msg){
        console.log(JSON.parse(JSON.stringify(msg)));
    }

    App.log = function (text, fileName, lineNumber) {

        console.groupCollapsed('Debug Msg');

        if (!_.isUndefined(fileName))
            console.info('File Name: ' + fileName);

        if (!_.isUndefined(lineNumber))
            console.info('Line Number : ' + lineNumber);

        if (_.isUndefined(text))
            console.log('No message to function App.log');
        else
            console.log(text);

        console.groupEnd();
    };

    App.vent = _.extend({}, Backbone.Events);

    return App;
});
