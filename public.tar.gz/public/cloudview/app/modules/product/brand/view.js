define([
	'App',
	'modules/product/brand/brandTable/view',
	'modules/product/category/categoryCollection/view',
	'modules/product/brand/addBrandItem/view',
	'modules/product/brand/brandTable/model',
	'text!modules/product/brand/template.html',
],
function(
	App,
	BrandTableView,
	CategoryListView,
	AddBrandView,
	BrandModel,
	template
){
	return Backbone.Marionette.LayoutView.extend({
		template: _.template(template),
		regions:{
			table: "#tableB",
			list:".categoryDropdownList",
			form : ".formB"
		},
		events:{
			"click #addBtnB" : "toggle",
			//"click #saveBrand" : "saveBrandFun",
			//"click .showBrands" : "showBrandsFun",
		},
		childEvents:{
			"changed" :function(){this.getRegion('table').show(new BrandTableView());}
		},

		toggle : function(){
		    this.getRegion('form').show(new AddBrandView({model: new BrandModel }));
			this.$('.formB').show();
		},
		showBrandsFun: function(){
			this.getRegion('table').show(new BrandTableView());
        },
		onRender : function(){
			//this.getRegion('table').show(new BrandTableView());
			this.getRegion('list').show(new CategoryListView());
		},
	});
});